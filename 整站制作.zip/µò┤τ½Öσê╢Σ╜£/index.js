
    //调整内容的高度
    var h = $(window).innerHeight();
    $('.container').css('height', h);
    $('.content').css('height', h);
    var $dots = $('nav').find('a');
    location.hash = '#home';

    /************右侧圆点点击事件***********/
    $dots.on('click', function () {
        scrollNum = $dots.index($(this));
        pageChange();
    });

    /************屏幕滚动事件***********/
    var scrollNum = 0;
    var isScroll = false;

    if (document.attachEvent) {
        document.attachEvent("onmousewheel", function(e) {
            mousewheelEvent(e);
        });
    }
    else if (document.addEventListener) {

        document.addEventListener("DOMMouseScroll", function(e) {
            mousewheelEvent(e);
        }, false);
        document.addEventListener("wheel", function(e) {
            mousewheelEvent(e);
        }, false);
        document.addEventListener("onmousewheel", function(e) {
            mousewheelEvent(e);
        }, false);
    }

    function mousewheelEvent(e) {
        if (!isScroll){
            isScroll = !isScroll;
            var e = e || window.event;
            var value = e.wheelDelta || -e.deltaY || -e.detail;
            var delta = Math.max(-1, Math.min(1, value));
            if(delta < 0 && scrollNum < 2){
                scrollNum++;
            }else if (delta > 0 && scrollNum > 0){
                scrollNum--;
            }
            pageChange();
        }
    }

    function pageChange() {
        if(scrollNum == 0){
            firstPageAnimation();
        }else {
            firstDisappear();
        }
        if (scrollNum == 1){
            secondPageAnimation();
        }else {
            secondDisappear();
        }
        if (scrollNum == 2){
            thirdPageAnimation();
        }else {
            thirdDisappear();
        }
        $dots.delay(500).eq(scrollNum).addClass('active').siblings().removeClass('active');
        $('.container').find('.content-list').animate({top:-h * scrollNum}, 500);
        setTimeout(function () {
            isScroll = !isScroll;
        }, 1500);
    }

    /************第一页动画***********/
    var $logoCenter = $('.content1').find('.logo-center');
    var $center = $('.content1').find('.center');
    $center.fadeOut(0);
    $logoCenter.css('top', -2000);
    firstPageAnimation();
    function firstPageAnimation() {
        $center.delay(700).fadeIn(500);
        $logoCenter.animate({top:0}, 1000);
    }
    function firstDisappear() {
        $center.fadeOut(0);
        $logoCenter.css({top:-2000});
    }
    /************第2页动画***********/
    var $aCont = $('.content_2').find('.content').find('li');

    function secondPageAnimation() {
        $aCont.each(function (i, e) {
            $aCont.eq(i).delay(i * 200).animate({top:0, opacity:1}, 1000);
        })
    }
    function secondDisappear() {
        $aCont.css({top:-60, opacity:0}).removeClass('in');
    }
    $aCont.on('mouseover', function () {
        $(this).addClass('in').siblings().removeClass('in');
    })

    /************第3页动画***********/

    var $intro = $('.content-intro');
    var $icon = $('.intro-icon');
    var $introInfo = $('.intro-em');
    var timer = null;
    var num = 0;
    var left = $intro.innerWidth();
    var top = $icon.eq(0).innerHeight()/2;

    var $pointerRight = $intro.find('.pointer-right');
    var $pointerleft = $intro.find('.pointer-left');

    $intro.css('top', ($(window).height() - $intro.innerHeight())/2);
    $icon.each(function (i, e) {
        $(this).css('left', ($intro.innerWidth() - $(this).innerWidth())/2);
        if(i > 0){
            $(this).css({left:$intro.innerWidth(),top:$(this).innerHeight()/2,opacity:0});
        }
    });
    $introInfo.each(function (i, e) {
        $(this).css('top', 280);
        if(i > 0){
            $(this).css({left:$intro.innerWidth(),top:$(window).height()/2 + $intro.innerHeight(),opacity:1});
        }
    });

    function startAnimation() {
        num++;
        if(num >= $icon.length){
            num = 0;
        }
        $icon.eq(num).siblings('.intro-icon').animate({left:-left,top:top,opacity:0}, 1000);
        $introInfo.eq(num).siblings('.intro-em').delay(1000).animate({left:-left,top:280 + top,opacity:0}, 1000);
        $icon.eq(num).animate({left:($intro.innerWidth() - $icon.eq(num).innerWidth())/2,top:0,opacity:1}, 1000);
        $introInfo.eq(num).delay(800).animate({left:0,top:280,opacity:1}, 1000);
        setTimeout(function () {
            $icon.eq(num).siblings('.intro-icon').css('left', left);
            $introInfo.eq(num).siblings('.intro-em').css('left', left);
        }, 3000);
    }

    function thirdPageAnimation() {
        $('.about-ice').animate({top:-25}, 1500).css('opacity', 1);
        if (timer == null){
            $pointerRight.each(function (i, e) {
                $(this).animate({left:this.offsetLeft - 60, opacity:1}, 1500);
            });
            $pointerleft.each(function (i, e) {
                $(this).animate({left:this.offsetLeft + 60, opacity:1}, 1500);
            });
            timer = setInterval(startAnimation, 4000);
        }
    }
    function thirdDisappear() {
        $('.about-ice').css({top:-200, opacity:0});
    }








