/**
 * Created by mengxiaojia on 2017/1/10.
 */
location.hash = '#case';
/**********banner轮播图************/
var $banner = $('.banner');
var $contents = $banner.find('.content');
var $bannerImg = $banner.find('.card');
var $bannerBg = $banner.find('.banner-bg').find('.bg');
var $btns = $banner.find('.banner-imgs2').find('.btn');
var $contentImg = $banner.find('.banner-imgs2').find('.content');
var num = 0;
var w = $contentImg.eq(0).innerWidth();
var timer = null;
$btns.eq(0).on('click', function () {
    clearInterval(timer);
    $contentImg.eq(num).animate({left:-w}, 1000, function () {
        $(this).css('left', w);
    });
    $contents.eq(num).animate({left:-w}, 1000, function () {
        $(this).css('left', w);
    });
    $bannerBg.eq(num).delay(500).animate({opacity:0}, 500);
    num--;
    if (num < 0){
        num = $contentImg.length - 1;
    }
    $contents.eq(num).animate({left:0}, 1000);
    $contentImg.eq(num).animate({left:0}, 1000);
    $bannerBg.eq(num).delay(500).animate({opacity:1}, 500);
    timer = setInterval(nextPage, 8000);
});
$btns.eq(1).on('click',function () {
    clearInterval(timer);
    nextPage();
    timer = setInterval(nextPage, 8000);
});
timer = setInterval(nextPage, 8000);

function nextPage() {
    $contentImg.eq(num).animate({left:-w}, 1000, function () {
        $(this).css('left', w);
    });
    $contents.eq(num).animate({left:-w}, 1000, function () {
        $(this).css('left', w);
    });
    $bannerBg.eq(num).delay(500).animate({opacity:0}, 500);
    num++;
    if (num >= $contentImg.length){
        num = 0;
    }

    $contents.eq(num).animate({left:0}, 1000);
    $contentImg.eq(num).animate({left:0}, 1000);
    $bannerBg.eq(num).delay(500).animate({opacity:1}, 500);
}
bannerRotate();
function bannerRotate() {
    $bannerImg.css({transform:'rotateZ(-90deg) rotateY(45deg) translateX(440px)'});
    $bannerImg.eq(1).css({transform:'rotateZ(-90deg) rotateY(45deg) translateX(480px)'});
    $bannerImg.eq(2).css({transform:'rotateZ(-90deg) rotateY(45deg) translateX(520px)'});
    $bannerImg.each(function (i, e) {
        $(this).delay(1000).animate({top:this.offsetTop + i * 100}, i*1000);

    })

}

/**************************************************/
var $mainCont = $('.main-contant');
var $mainTitle = $mainCont.find('.child');
var $mainTitleBg = $mainCont.find('.nav-bg');
var $content = $mainCont.find('.content');
$mainTitle.on('click', function () {
    $mainTitleBg.animate({left:this.offsetLeft}, 200);
    $(this).addClass('active').siblings().removeClass('active');
    $content.show(100);
    switchContent($mainTitle.index($(this)));
});

function switchContent(num) {
    switch (num){
        case 0:
            break;
        case 1:
            $content.not('.mobile').hide();
            break;
        case 2:
            $content.not('.website').hide();
            break;
        case 3:
            $content.not('.logo').hide();
            break;
        case 4:
            $content.not('.flat').hide();
            break;
    }
}


//滚动事件
var $nums = $banner.find('.mun-title').find('.num');

$(document).scroll(function () {

    var $h = $(window).height();
    if ($(document).scrollTop() >= $nums.offset().top - $h + 10){
        $nums.each(function (i, e) {
            $(this).countTo({
                from:            parseInt($(this).html()),
                to:              $(this).attr('countTo'),
                speed:           300,
                refreshInterval:  1
            });
        });
    }

});

$.fn.countTo = function (options) {
    options = options || {};

    return $(this).each(function () {
        // set options for current element
        var settings = $.extend({}, $.fn.countTo.defaults, {
            from:            $(this).data('from'),
            to:              $(this).data('to'),
            speed:           $(this).data('speed'),
            refreshInterval: $(this).data('refresh-interval'),
            decimals:        $(this).data('decimals')
        }, options);

        // how many times to update the value, and how much to increment the value on each update
        var loops = Math.ceil(settings.speed / settings.refreshInterval),
            increment = (settings.to - settings.from) / loops;

        // references & variables that will change with each update
        var self = this,
            $self = $(this),
            loopCount = 0,
            value = settings.from,
            data = $self.data('countTo') || {};

        $self.data('countTo', data);

        // if an existing interval can be found, clear it first
        if (data.interval) {
            clearInterval(data.interval);
        }
        data.interval = setInterval(updateTimer, settings.refreshInterval);

        // initialize the element with the starting value
        render(value);

        function updateTimer() {
            value += increment;
            loopCount++;

            render(value);

            if (typeof(settings.onUpdate) == 'function') {
                settings.onUpdate.call(self, value);
            }

            if (loopCount >= loops) {
                // remove the interval
                $self.removeData('countTo');
                clearInterval(data.interval);
                value = settings.to;

                if (typeof(settings.onComplete) == 'function') {
                    settings.onComplete.call(self, value);
                }
            }
        }

        function render(value) {
            var formattedValue = settings.formatter.call(self, value, settings);
            $self.html(formattedValue);
        }
    });
};

$.fn.countTo.defaults = {
    from: 0,               // the number the element should start at
    to: 0,                 // the number the element should end at
    speed: 1000,           // how long it should take to count between the target numbers
    refreshInterval: 100,  // how often the element should be updated
    decimals: 0,           // the number of decimal places to show
    formatter: formatter,  // handler for formatting the value before rendering
    onUpdate: null,        // callback method for every time the element is updated
    onComplete: null       // callback method for when the element finishes updating
};

function formatter(value, settings) {
    return value.toFixed(settings.decimals);
}