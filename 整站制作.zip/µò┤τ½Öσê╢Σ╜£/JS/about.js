/**
 * Created by mengxiaojia on 2017/1/12.
 */
location.hash = '#about';
"use strict"
/*****头像动画****/
$('.person-bor ,.person-con').css('transform', 'scale(1)');
$('.person-bor').delay(500).css('animationName', 'person');

/********浪花动画--白的浪花随鼠标动*******/
var $lang = $('.banner').find('.banner-langs').find('.lang1');
$(document).mousemove(function (ev) {
    // console.log(ev.pageX);
    $lang.css('transform', 'translateX('+-ev.pageX/15+'px)');

});

var $service = $('.service');
var $titles = $service.find('.titles');
var $btns = $service.find('.btns').children();
var $links = $service.find('.links').children();
var $contents = $service.find('.content').find('.child');
$(document).scroll(function () {
    var $h = $(window).height();
    if($(document).scrollTop() >= $titles.offset().top - $h + 10){
        // alert(1);
        $titles.children().delay(1000).removeClass('in');
    }
    if($(document).scrollTop() >= $btns.offset().top - $h + 10){
        // alert(1);
        $btns.css('transform','scale(1)');
    }
    if($(document).scrollTop() >= $links.offset().top - $h + 10){
        // alert(1);
        $links.css('transform','scale(1)');
    }
    $contents.each(function (i, e) {
        if($(document).scrollTop() >= $(this).offset().top - $h - 50){
            // alert(1);
            $(this).delay(5000).css('transform','scale(1)');
        }
    })
    if($(document).scrollTop() >= $ability.offset().top - $h + 100){
        // alert(1);
        abilityFirstAppear();
    }
});
/***********ability-contents*************/
var $ability = $('.ability');
var $abilityContents1 = $ability.find('.content-1').children();
var $abilityContents2 = $ability.find('.content-2').children();
var $abilityNavs = $ability.find('.ability-navs').children();
var $abilityBtn = $ability.find('.ability-btn');
var traggle = false;
$abilityContents2.each(function (i, e) {
    $(this).css('transitionDelay', 0.1 * i +'s');
});
initAbilityContents1();
// abilityFirstAppear();
$abilityNavs.on('click', function () {
    // alert(1);
    if($abilityNavs.index($(this)) == 1){
        $abilityContents2.closest('.content-2').show();
        $abilityContents2.css('transform', 'scale(1)');
        abilityFirstDisappear();
    }else {
        $abilityContents2.css('transform', 'scale(0)').closest('.content-2').hide();
        abilityFirstAppear();
    }
    $(this).addClass('on').siblings().removeClass('on');
});
$abilityBtn.click(function () {
    if(!traggle){
        $abilityNavs.eq(1).addClass('on').siblings().removeClass('on');
        $abilityContents2.closest('.content-2').show();
        $abilityContents2.css('transform', 'scale(1)');
        abilityFirstDisappear();
    }else {
        $abilityNavs.eq(0).addClass('on').siblings().removeClass('on');
        $abilityContents2.css('transform', 'scale(0)').closest('.content-2').hide();
        abilityFirstAppear();
    }
    traggle = !traggle;

});

function initAbilityContents1() {
    $abilityContents1.each(function (i, e) {
        $(this).find('.child-img').find('img').css('transitionDelay', 0.2 * i +'s');
        $(this).find('.title').css({transitionDelay:0.2 * i +'s'} );
        $(this).find('.info').css({transitionDelay:0.1 + 0.2 * i +'s'} );

    });
}

function abilityFirstAppear() {
    $abilityContents1.closest('.content-1').show();
    $abilityContents1.find('.child-img').find('img').css('transform', 'scale(1)');
    $abilityContents1.find('.title').css('transform', 'translateX(0)');
    $abilityContents1.find('.info').css('transform', 'translateX(0)');
}
function abilityFirstDisappear() {
    $abilityContents1.closest('.content-1').hide();
    $abilityContents1.find('.child-img').find('img').css('transform', 'scale(0)');
    $abilityContents1.find('.title').css('transform', 'translateX(-390px)');
    $abilityContents1.find('.info').css('transform', 'translateX(-390px)');
}

/********底部轮播图********/
var $abouts = $('.abouts');
var $aboutContents = $abouts.find('.content');
var $aboutNavs = $abouts.find('.about-navs').children();
var timer = null;
var num = 0;
var $w = $aboutContents.innerWidth();
timer = setInterval(nextPage, 5000);
var moveOver = true;
$aboutNavs.click(function () {
    if(moveOver){
        moveOver = false;
        clearInterval(timer);
        $aboutContents.eq(num).animate({left:-$w}, 1000).siblings().css('left',$w);
        $aboutNavs.eq(num).removeClass('on');
        num = $aboutNavs.index($(this));
        $aboutNavs.eq(num).addClass('on');
        $aboutContents.eq(num).animate({left:0}, 1000);
        timer = setInterval(nextPage, 5000);
        setTimeout(function () {
            moveOver = true;
        }, 1000);
    }
});
function nextPage() {
    $aboutContents.eq(num).animate({left:-$w}, 1000).siblings().css('left',$w);
    $aboutNavs.eq(num).removeClass('on');
    num++;
    if(num >= $aboutContents.length){
        num = 0;
    }
    $aboutNavs.eq(num).addClass('on');
    $aboutContents.eq(num).animate({left:0}, 1000);
}