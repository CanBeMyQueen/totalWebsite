/**
 * Created by mengxiaojia on 2017/1/18.
 */
location.hash = '#mall';