/**
 * Created by mengxiaojia on 2017/1/18.
 */
location.hash = '#contact';

/*
*
* 第一页动画
* */
var $container = $('.container');
var $contents = $container.find('.content');
var $mountains = $container.find('.mountains').find('.mountain');
/*
* 鼠标晃动背景跟动事件
* */
$(document).mousemove(function (ev) {
    // console.log(ev.pageX);
    $mountains.each(function (i, e) {
        (function (i) {
            if(i == 0 || i== 3){
                $mountains.eq(i).css('transform', 'translateX('+-ev.pageX/(15 + 2*i)+'px)');
            }else {
                $mountains.eq(i).css('transform', 'translateX('+ev.pageX/(15 + i*2)+'px)');
            }
        })(i);

    });
});

/*
 * 第一页文本内容进入动画
 * */
var $infos = $container.find('.content1').find('.infos').children();
firstPageAnimation();
function firstPageAnimation() {
    $infos.each(function (i, e) {
        (function (i) {
            switch (i){
                case 0:
                    setTimeout(function () {
                        $infos.eq(i).css('transform','translateX(0)');
                    }, i * 200);
                    break;
                case 1:
                    setTimeout(function () {
                        $infos.eq(i).css('transform','translateX(0)');
                    }, i * 100);
                    break;
                case 3:
                    setTimeout(function () {
                        $infos.eq(i).css('transform','translateX(0)');
                    },  500);
                    break;
                case 4:
                    setTimeout(function () {
                        $infos.eq(i).css('transform','translateX(0)');
                    },  600);
                    break;
            }
        })(i)
    })
}

/*
*
* 调整内容的高度
* 可视区大小变化事件
* */
var h = $(window).innerHeight();
$container.css('height', h);
$contents.css('height', h);

$(window).resize(function () {
    var rh = $(window).height();
    h = rh;
    // alert(rh);
    $container.css('height', rh);
    $contents.css('height', rh);
    // alert($contents.css('height'));
});

/************
 *
 * 右侧圆点点击事件
 *
 * ***********/
var $dots = $('nav').find('a');
$dots.on('click', function () {
    scrollNum = $dots.index($(this));
    pageChange();
});

/********************
 *
 * 屏幕滚动事件
 *
 * *******************/
var scrollNum = 0;
var isScroll = false;
if (document.attachEvent) {
    document.attachEvent("onmousewheel", function(e) {
        mousewheelEvent(e);
    });
}
else if (document.addEventListener) {
    document.addEventListener("DOMMouseScroll", function(e) {
        mousewheelEvent(e);
    }, false);
    document.addEventListener("wheel", function(e) {
        mousewheelEvent(e);
    }, false);
    document.addEventListener("onmousewheel", function(e) {
        mousewheelEvent(e);
    }, false);
}
function mousewheelEvent(e) {
    if (!isScroll){
        isScroll = !isScroll;
        var e = e || window.event;
        var value = e.wheelDelta || -e.deltaY || -e.detail;
        var delta = Math.max(-1, Math.min(1, value));
        // alert(delta);
        if(delta < 0 && scrollNum < 2){
            scrollNum++;
        }else if (delta > 0 && scrollNum > 0){
            scrollNum--;
        }
        pageChange();
    }
}

var $moveModel = $('.move-model');
var $phone = $moveModel.find('.phone');
var $support = $moveModel.find('.support');
$support.find('.close').on('click', function () {
    $support.removeClass('on');
    $support.hide();
});
var $photos = $moveModel.find('.photos');
function pageChange() {
    if(scrollNum == 0){
        $moveModel.fadeOut(0);
        $moveModel.removeClass('move-model1 move-model2');
        $phone.removeClass('in');
        $support.removeClass('on');
    }else {
        $moveModel.fadeIn(0);
        if(scrollNum == 1){
            $phone.show();
            $phone.addClass('in');
            $moveModel.addClass('move-model1').removeClass('move-model2');
        }else{
            $phone.removeClass('in');
            $phone.hide();
        }
        if(scrollNum == 2){
            $support.show();
            $support.addClass('on');
            $moveModel.addClass('move-model2').removeClass('move-model1');
        }else{
            $support.removeClass('on');
            $support.hide();
        }
    }
    // alert(scrollNum);
    $contents.eq(scrollNum).animate({top:0}, 500);
    $contents.eq(scrollNum).nextAll().animate({top:h}, 500);
    $contents.eq(scrollNum).prevAll().animate({top:-h}, 500);
    $dots.delay(500).eq(scrollNum).addClass('active').siblings().removeClass('active');
    setTimeout(function () {
        isScroll = !isScroll;
    }, 1000);
}
