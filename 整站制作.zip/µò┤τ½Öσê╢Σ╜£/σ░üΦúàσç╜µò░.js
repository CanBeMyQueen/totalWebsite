
function getId(id){
    return document.getElementById(id);
}

function getClassName(className){
    return document.getElementsByClassName(className);
}

function getTagName(obj){
    return document.getElementsByTagName(obj);
}

function  getStyle(object, attr){
    return object.currentStyle?object.currentStyle[attr]:getComputedStyle(object)[attr];
}

//抖动封装
function shake(obj, attr,callBack){
    clearInterval(obj.shake);
    var positionValue = parseInt(getStyle(obj, attr));
    var nums = [];
    var num = 0;
    for (var i = 20; i > 0; i -= 2){
        nums.push(i, -i);
    }
    nums.push(0);
    obj.shake = setInterval(function(){

        obj.style[attr] = positionValue + nums[num] + 'px';
        num++;
        if (num > nums.length){
            callBack&&callBack(obj);
            clearInterval(obj.shake);
        }
    }, 30);
}

function startMove(obj, target, attr, callBack){
    obj.style[target] = attr + 'px';
    callBack&&callBack(obj);
}

//移动封装
function move(obj, target, attr, cell, block){
    clearInterval(obj.move);

    cell = parseFloat(getStyle(obj,attr))<target?cell:-cell;
    obj.move = setInterval(function(){

        var value = parseFloat(getStyle(obj,attr)) + cell;
        if (value > target && cell > 0 || value < target && cell < 0){
            value = target;
            clearInterval(obj.move);
            block&&block(obj);
        }

        obj.style[attr] = value + 'px';
    }, 20);

}

//移动封装
function domove(obj, target, block){
    clearInterval(obj.move);
    for(var s in target){
        cell = parseFloat(getStyle(obj,target[s]))<target?cell:-cell;
        obj.style[target[s]] = value + 'px';
    }
    cell = parseFloat(getStyle(obj,attr))<target?cell:-cell;
    obj.move = setInterval(function(){

        var value = parseFloat(getStyle(obj,attr)) + cell;
        if (value > target && cell > 0 || value < target && cell < 0){
            value = target;
            clearInterval(obj.move);
            block&&block(obj);
        }

        obj.style[attr] = value + 'px';
    }, 20);

}


//透明度封装
function opacity(obj, attr, val, callback){
    clearInterval(obj.opacity);
    var originAlpha = getStyle(obj, attr);

    if(attr == "opacity") {
        originAlpha *= 100;
        if (originAlpha == val){
            clearInterval(obj.opacity);
            return;
        }else {
            var num = originAlpha>val?-1:1;
        }
        obj.opacity = setInterval(function(){
            originAlpha += num;
            obj.style[attr] = originAlpha/100;
//                        obj.style.filter = "alpha(opacity = "+originAlpha+")";
            if (originAlpha == val){
                clearInterval(obj.opacity);
                callback&&callback();
            }
        }, 20);


    }


}

/**
 * Created by apple on 16/9/28.
 */
