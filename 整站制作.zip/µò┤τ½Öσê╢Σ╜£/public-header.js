/**
 * Created by mengxiaojia on 2017/1/5.
 */
var $nav = $('.nav');
var $runArea = $('.runArea');
var $navCells = $nav.find('.navCell');
var selectedIndex = 0;
var hash = window.location.hash;
// alert(hash);
initColor(hash);
function initColor(hash) {
    switch(hash){
        case '#home':
            $runArea.css({left:$navCells.eq(0).offset().left, width:$navCells.eq(0).innerWidth()});
            break;
        case '#case':
            $runArea.css({left:$navCells.eq(1).offset().left, width:$navCells.eq(1).innerWidth()});
            $navCells.eq(1).find('a').css('color', '#402dff');
            break;
        case '#about':
            $runArea.css({left:$navCells.eq(2).offset().left, width:$navCells.eq(2).innerWidth()});
            $navCells.eq(2).find('a').css('color', '#402dff');
            break;
        case '#contact':
            $runArea.css({left:$navCells.eq(3).offset().left, width:$navCells.eq(3).innerWidth()});
            $navCells.eq(3).find('a').css('color', '#402dff');
            break;
        case '#mall':
            $runArea.css({left:$navCells.eq(4).offset().left, width:$navCells.eq(4).innerWidth()});
            $navCells.eq(4).find('a').css('color', '#402dff');
            break;
    }
}

$navCells.on('mouseover', function () {

    if ($(this).closest('.in').attr('class') === undefined){
        $(this).find('a').css('color', '#402dff');
    }
    move($runArea.get(0),$(this).offset().left, 'left', 30);
    widthChange($(this).innerWidth());
});
$navCells.on('mouseout', function (ev) {
    if ($(this).closest('.in').attr('class') === undefined){
        $(this).find('a').css('color', '#454545');
    }
    mouseoutChange(hash);

});

function mouseoutChange(hash) {
    switch(hash){
        case '#home':
            move($runArea.get(0),$navCells.eq(0).offset().left, 'left', 60);
            widthChange($navCells.eq(0).innerWidth());
            break;
        case '#case':
            $navCells.eq(1).find('a').css('color', '#402dff');
            move($runArea.get(0),$navCells.eq(1).offset().left, 'left', 60);
            widthChange($navCells.eq(1).innerWidth());
            break;
        case '#about':
            $navCells.eq(2).find('a').css('color', '#402dff');
            move($runArea.get(0),$navCells.eq(2).offset().left, 'left', 60);
            widthChange($navCells.eq(2).innerWidth());
            break;
        case '#contact':
            $navCells.eq(3).find('a').css('color', '#402dff');
            move($runArea.get(0),$navCells.eq(3).offset().left, 'left', 60);
            widthChange($navCells.eq(3).innerWidth());
            break;
        case '#mall':
            $navCells.eq(4).find('a').css('color', '#402dff');
            move($runArea.get(0),$navCells.eq(4).offset().left, 'left', 60);
            widthChange($navCells.eq(4).innerWidth());
            break;
    }
}

function change(num) {
    move($runArea.get(0),$navCells.eq(0).offset().left, 'left', 60);
    widthChange($navCells.eq(0).innerWidth());
}

function widthChange(target) {
    $runArea.get(0).style.width = target + 'px';
}

//移动封装
function move(obj, target, attr, cell, block){
    clearInterval(obj.move);

    cell = parseFloat(getStyle(obj,attr))<target?cell:-cell;
    obj.move = setInterval(function(){

        var value = parseFloat(getStyle(obj,attr)) + cell;
        if (value > target && cell > 0 || value < target && cell < 0){
            value = target;
            clearInterval(obj.move);
            block&&block(obj);
        }
        obj.style[attr] = value + 'px';
    }, 20);

}
function  getStyle(object, attr){
    return object.currentStyle?object.currentStyle[attr]:getComputedStyle(object)[attr];
}

var $fixed = $('.fixed');
var $fixedTop = $fixed.find('.fixed-top');
var $logos = $('.cooperate').find('img');
var $subContent = $('.footer').find('.sub-content');
$fixedTop.on('click', function () {
    $('body,html').animate({scrollTop:0},500);
})
$(document).scroll(function () {
    if(hash == '#case' || hash == '#about'){
        if($(document).scrollTop() > 2000){
            $fixed.fadeIn(300);
        }else {
            $fixed.fadeOut(300);
        }
        var $h = $(window).height();
        if ($(document).scrollTop() >= $logos.offset().top - $h + 10){
            $logos.each(function (i, e) {
                $(this).delay(100).animate({marginTop:0, opacity:1}, 500);
            })

        }
        if ($(document).scrollTop() >= $subContent.offset().top - $h + 10){
            $subContent.each(function (i, e) {
                $(this).delay(i * 200).animate({marginTop:0}, 1000);
            })

        }
    }

});
if(hash != '#home' && hash != '#contact'){
    if (document.attachEvent) {
        document.attachEvent("onmousewheel", function(e) {
            mousewheelEvent1(e);
        });
    }
    else if (document.addEventListener) {
        document.addEventListener("DOMMouseScroll", function(e) {
            mousewheelEvent1(e);
        }, false);
        document.addEventListener("wheel", function(e) {
            mousewheelEvent1(e);
        }, false);
        document.addEventListener("onmousewheel", function(e) {
            mousewheelEvent1(e);
        }, false);
    }
}


var $header = $('.header');
function mousewheelEvent1(e){
    var e = e || window.event;
    var value = e.wheelDelta || -e.deltaY || -e.detail;
    var delta = Math.max(-1, Math.min(1, value));
    if(delta < 0 ){
        $header.animate({top:-70}, 300);
    }else if (delta > 0){
        $header.animate({top:0}, 300);
    }
}